using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PwCStationeryAPI.Models;

namespace PwCStationeryAPI.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Item> Items => Set<Item>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Supplier> Suppliers => Set<Supplier>();
        public DbSet<Office> Offices => Set<Office>();
        public DbSet<StockLevel> StockLevels => Set<StockLevel>();
        public DbSet<Request> Requests => Set<Request>();
        public DbSet<Delivery> Deliveries => Set<Delivery>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        // Issue/Return entities
        public DbSet<Issue> Issues => Set<Issue>();
        public DbSet<IssueLine> IssueLines => Set<IssueLine>();
        public DbSet<Return> Returns => Set<Return>();
        public DbSet<ReturnLine> ReturnLines => Set<ReturnLine>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // ---------- Item ----------
            modelBuilder.Entity<Item>(b =>
            {
                b.Property(i => i.Name).HasMaxLength(150).IsRequired();
                b.Property(i => i.Description).HasMaxLength(500);
                b.HasOne(i => i.Category).WithMany().HasForeignKey(i => i.CategoryId).OnDelete(DeleteBehavior.Restrict);
                b.HasOne(i => i.Supplier).WithMany().HasForeignKey(i => i.SupplierId).OnDelete(DeleteBehavior.SetNull);
                b.HasIndex(i => i.Name);
            });

            // ---------- Category ----------
            modelBuilder.Entity<Category>(b =>
            {
                b.Property(c => c.Name).HasMaxLength(100).IsRequired();
                b.HasIndex(c => c.Name);
            });

            // ---------- Supplier ----------
            modelBuilder.Entity<Supplier>(b =>
            {
                b.Property(s => s.Name).HasMaxLength(120).IsRequired();
                b.Property(s => s.ContactEmail).HasMaxLength(200);
                b.Property(s => s.Phone).HasMaxLength(50);
                b.HasIndex(s => s.Name);
            });

            // ---------- Office ----------
            modelBuilder.Entity<Office>(b =>
            {
                b.Property(o => o.Name).HasMaxLength(120).IsRequired();
                b.Property(o => o.Location).HasMaxLength(120);
                b.HasIndex(o => o.Name);
            });

            // ---------- StockLevel ----------
            modelBuilder.Entity<StockLevel>(b =>
            {
                b.HasOne(s => s.Item).WithMany().HasForeignKey(s => s.ItemId).OnDelete(DeleteBehavior.Cascade);
                b.HasOne(s => s.Office).WithMany().HasForeignKey(s => s.OfficeId).OnDelete(DeleteBehavior.Cascade);
                b.Property(s => s.ReorderThreshold).HasDefaultValue(0);
                b.HasIndex(s => new { s.ItemId, s.OfficeId }).IsUnique();
            });

            // ---------- Request ----------
            modelBuilder.Entity<Request>(b =>
            {
                b.Property(r => r.ItemName).HasMaxLength(150).IsRequired();
                b.Property(r => r.Office).HasMaxLength(120).IsRequired();
                b.Property(r => r.Status).HasMaxLength(30).HasDefaultValue("Pending");
                b.HasIndex(r => new { r.Office, r.Status });
            });

            // ---------- Delivery ----------
            modelBuilder.Entity<Delivery>(b =>
            {
                b.Property(d => d.Product).HasMaxLength(150).IsRequired();
                b.Property(d => d.Office).HasMaxLength(120).IsRequired();
                b.Property(d => d.Status).HasMaxLength(30).IsRequired();

                b.Property(d => d.OrderedDateUtc).IsRequired();
                b.Property(d => d.ExpectedArrivalDateUtc);
                b.Property(d => d.ActualArrivalDateUtc);
                b.Property(d => d.FinalDelayDays);

                b.HasOne(d => d.Supplier).WithMany().HasForeignKey(d => d.SupplierId).OnDelete(DeleteBehavior.SetNull);

                b.HasIndex(d => d.OrderedDateUtc);
                b.HasIndex(d => new { d.Office, d.Status });
            });

            // ---------- AuditLog ----------
            modelBuilder.Entity<AuditLog>(b =>
            {
                b.HasKey(a => a.Id);
                b.Property(a => a.Method).HasMaxLength(16);
                b.Property(a => a.Path).HasMaxLength(512);
                b.Property(a => a.Controller).HasMaxLength(128);
                b.Property(a => a.Action).HasMaxLength(128);
                b.Property(a => a.UserId).HasMaxLength(128);
                b.Property(a => a.UserName).HasMaxLength(256);
                b.Property(a => a.RolesCsv).HasMaxLength(256);
                b.Property(a => a.Ip).HasMaxLength(64);
                b.Property(a => a.UserAgent).HasMaxLength(512);
                b.HasIndex(a => a.TimestampUtc);
                b.HasIndex(a => a.Path);
                b.HasIndex(a => new { a.Method, a.StatusCode });
            });

            // ---------- Issue ----------
            modelBuilder.Entity<Issue>(b =>
            {
                b.HasKey(i => i.Id);
                b.HasIndex(i => i.RequestId).IsUnique(); // one Issue per Request

                b.HasOne(i => i.Request)
                    .WithMany()
                    .HasForeignKey(i => i.RequestId)
                    .OnDelete(DeleteBehavior.Cascade);

                // user link is just a string (no FK)
                b.Property(i => i.IssuedByUserId).HasMaxLength(128);
            });

            modelBuilder.Entity<IssueLine>(b =>
            {
                b.HasKey(l => l.Id);
                b.HasOne(l => l.Issue)
                    .WithMany(i => i.Lines)
                    .HasForeignKey(l => l.IssueId)
                    .OnDelete(DeleteBehavior.Cascade);

                b.HasOne(l => l.Item)
                    .WithMany()
                    .HasForeignKey(l => l.ItemId)
                    .OnDelete(DeleteBehavior.Restrict);
            });

            // ---------- Return ----------
            modelBuilder.Entity<Return>(b =>
            {
                b.HasKey(r => r.Id);
                b.HasOne(r => r.Issue)
                    .WithMany()
                    .HasForeignKey(r => r.IssueId)
                    .OnDelete(DeleteBehavior.Cascade);

                // user link is just a string (no FK)
                b.Property(r => r.ReturnedByUserId).HasMaxLength(128);
            });

            modelBuilder.Entity<ReturnLine>(b =>
            {
                b.HasKey(l => l.Id);
                b.HasOne(l => l.Return)
                    .WithMany(r => r.Lines)
                    .HasForeignKey(l => l.ReturnId)
                    .OnDelete(DeleteBehavior.Cascade);

                b.HasOne(l => l.Item)
                    .WithMany()
                    .HasForeignKey(l => l.ItemId)
                    .OnDelete(DeleteBehavior.Restrict);
            });
        }
    }
}
