﻿using Microsoft.AspNetCore.Identity;

namespace PwCStationeryAPI.Models
{
    public class ApplicationUser : IdentityUser
    {
        // extend later if needed (DisplayName, Office, etc.)
    }
}
