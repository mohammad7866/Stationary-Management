﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Text.Json;
using YourNamespace.Models;

namespace YourNamespace.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public sealed class SkipAuditAttribute : Attribute { }

    public class AuditLogActionFilter : IAsyncActionFilter
    {
        private readonly IDbContextFactory<YourDbContext> _dbFactory;
        public AuditLogActionFilter(IDbContextFactory<YourDbContext> dbFactory) => _dbFactory = dbFactory;

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            // Skip if annotated
            if (context.ActionDescriptor.EndpointMetadata.OfType<SkipAuditAttribute>().Any())
            {
                await next(); return;
            }

            var http = context.HttpContext;
            var sw = System.Diagnostics.Stopwatch.StartNew();

            var user = http.User;
            string? userId = user.FindFirstValue(ClaimTypes.NameIdentifier) ?? user.FindFirstValue("sub");
            string? userName = user.Identity?.Name ?? user.FindFirstValue(ClaimTypes.Name);
            var rolesCsv = string.Join(",", user.FindAll(ClaimTypes.Role).Select(c => c.Value));

            var routeVals = JsonSerializer.Serialize(context.RouteData.Values);
            var query = http.Request.QueryString.HasValue ? http.Request.QueryString.Value : null;

            // Optional: small body preview (safe)
            string? bodyPreview = null;
            if (http.Request.ContentLength is > 0 && http.Request.Body.CanSeek)
            {
                http.Request.Body.Position = 0;
                using var reader = new StreamReader(http.Request.Body, leaveOpen: true);
                var body = await reader.ReadToEndAsync();
                http.Request.Body.Position = 0;
                bodyPreview = body.Length > 512 ? body.Substring(0, 512) : body;
            }

            var executed = await next();
            sw.Stop();

            try
            {
                await using var db = await _dbFactory.CreateDbContextAsync();
                var log = new AuditLog
                {
                    TimestampUtc = DateTime.UtcNow,
                    UserId = userId,
                    UserName = userName,
                    RolesCsv = rolesCsv,

                    Method = http.Request.Method,
                    Path = http.Request.Path.Value ?? "",
                    Controller = context.ActionDescriptor.RouteValues.TryGetValue("controller", out var c) ? c : null,
                    Action = context.ActionDescriptor.RouteValues.TryGetValue("action", out var a) ? a : null,
                    RouteValuesJson = routeVals,
                    QueryString = query,
                    BodyPreview = bodyPreview,

                    StatusCode = http.Response?.StatusCode ?? 0,
                    DurationMs = (int)sw.ElapsedMilliseconds,

                    Ip = http.Connection.RemoteIpAddress?.ToString(),
                    UserAgent = http.Request.Headers.UserAgent.ToString(),
                };

                db.AuditLogs.Add(log);
                await db.SaveChangesAsync();
            }
            catch
            {
                // Swallow logging errors to avoid affecting the API
            }
        }
    }
}
