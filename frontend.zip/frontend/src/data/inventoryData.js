const inventoryItems = [
  { id: 1, name: "A4 Paper", category: "Core", stock: 120, office: "London" },
  { id: 2, name: "Branded Envelopes", category: "Printed", stock: 45, office: "Manchester" },
  { id: 3, name: "Custom Notebooks", category: "Special", stock: 15, office: "Birmingham" },
  { id: 4, name: "Pens", category: "Core", stock: 200, office: "London" },
  { id: 5, name: "Letterheads", category: "Printed", stock: 30, office: "Manchester" },
];

export default inventoryItems;
